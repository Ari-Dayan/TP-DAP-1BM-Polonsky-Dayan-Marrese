package com.ort.usuarioycontrasea

class User(s: String, s1: String, s2: String) {
    var name : String = s
    var password : String = s1
    var email : String = s2

}